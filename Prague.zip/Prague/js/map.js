function myMap() {
  var mapCanvas = document.getElementById("map");
  var mapOptions = {
    center: new google.maps.LatLng(50.08804, 14.42076), zoom: 10
  };
  var map = new google.maps.Map(mapCanvas, mapOptions);
}